"""Recomputes the interval counts reported in Table III from agreement_intervals.csv."""
import csv
from collections import Counter
rows = list(csv.DictReader(open('agreement_intervals.csv')))
for tol in (0.05, 0.03):
    c = Counter(r['test_rule'] for r in rows if -tol < float(r['ci95_low']) and float(r['ci95_high']) < tol)
    print(f'within +/-{tol} (primary replay):', dict(c))
c = Counter(r['test_rule'] for r in rows if -0.03 < float(r['lead6_ci95_low']) and float(r['lead6_ci95_high']) < 0.03)
print('within +/-0.03 (6-h lead replay):', dict(c))
