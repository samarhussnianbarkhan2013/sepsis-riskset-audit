"""Summaries of results_01.json used by the tables and figures."""
import json, numpy as np
from scipy.stats import spearmanr
J = json.load(open('../results/results_01.json')); R = J['audit']
D = ['discharge', 'relative', 'absolute', 'feasible', 'riskset', 'riskset_future']
SET = ['AtoB', 'BtoA', 'AtoA', 'BtoB']
def seeds(s): return list(R[s]['seeds'].values())
def agg(s, f):
    v = np.array([f(r) for r in seeds(s)]); return v.mean(), v.min(), v.max()
S = {}
for s in SET:
    X = {}
    for d in D:
        X[d] = dict(
            lin=agg(s, lambda r: r['probes'][d]['linear_time']), nl=agg(s, lambda r: r['probes'][d]['nonlinear_time']),
            tc=agg(s, lambda r: r['probes'][d]['time_and_counts']), ks=agg(s, lambda r: r['probes'][d]['ks_time_test']),
            own=agg(s, lambda r: r['matrix'][d][d]), rs=agg(s, lambda r: r['matrix'][d]['riskset']),
            rep=agg(s, lambda r: r['replay'][d]['AUROC']), auprc=agg(s, lambda r: r['replay'][d]['AUPRC']),
            sens=agg(s, lambda r: r['replay'][d]['sens_at_5pct_alerts']),
            gap=agg(s, lambda r: r['matrix'][d][d] - r['replay'][d]['AUROC']),
            sirs=agg(s, lambda r: r['sirs'][d]),
            tr=seeds(s)[0]['cohorts'][d]['train'], te=seeds(s)[0]['cohorts'][d]['test'],
            ctrl_tr=agg(s, lambda r: r['cohorts'][d]['train']['control_landmarks']),
            uniq_tr=agg(s, lambda r: r['cohorts'][d]['train']['unique_control_stays']),
            ctrl_te=agg(s, lambda r: r['cohorts'][d]['test']['control_landmarks']),
            uniq_te=agg(s, lambda r: r['cohorts'][d]['test']['unique_control_stays']))
        bias, mae, rho = [], [], []
        for r in seeds(s):
            est = np.array([r['matrix'][m][d] for m in D]); rep = np.array([r['replay'][m]['AUROC'] for m in D])
            bias.append(np.mean(est - rep)); mae.append(np.mean(np.abs(est - rep))); rho.append(spearmanr(est, rep)[0])
        X[d].update(bias=np.mean(bias), mae=np.mean(mae), rho=np.mean(rho))
    X['_replay'] = R[s]['replay']; X['_nseeds'] = len(seeds(s))
    if 'bootstrap' in seeds(s)[0]: X['_boot'] = seeds(s)[0]['bootstrap']
    S[s] = X
CASESEL = J['case_selection']; SKV = J['sklearn_version']
