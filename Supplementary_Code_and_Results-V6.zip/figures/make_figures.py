"""Regenerates Figs. 1-3 of the paper from the JSON files in ../results. Run from this folder: python make_figures.py"""
import json, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

P = {2: json.load(open('../results/results_04.json'))}
import results_summary as PS
BLUE, ORANGE, AQUA, YEL = '#2a78d6', '#eb6834', '#1baf7a', '#eda100'
INK, INK2, GRID = '#0b0b0b', '#52514e', '#d9d8d4'
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 7, 'axes.edgecolor': INK2, 'axes.labelcolor': INK,
                     'xtick.color': INK2, 'ytick.color': INK2, 'axes.linewidth': 0.6, 'xtick.major.width': 0.6,
                     'ytick.major.width': 0.6, 'legend.frameon': False, 'savefig.dpi': 400})
W = 3.45

def clean(ax, grid_axis='y'):
    for s in ('top', 'right'): ax.spines[s].set_visible(False)
    ax.grid(axis=grid_axis, color=GRID, lw=0.5); ax.set_axisbelow(True)

# ---------- Fig 1: control-sampling rules ----------
o, h, nc = 30, 6, 33; t = o - h; nS, nL = 22, 60
rules = [('Discharge-anchored', nS - 1 - h, nL - 1 - h, False),
         ('Relative time', round(o * nS / nc) - h, round(o * nL / nc) - h, False),
         ('Absolute time', min(t, nS - 1), min(t, nL - 1), False),
         ('Feasible onset', 18 - h, t, True),
         ('Risk set', None, t, False)]
fig, axes = plt.subplots(len(rules), 1, figsize=(W, 3.6), sharex=True)
for ax, (lab, tS, tL, early) in zip(axes, rules):
    ax.plot([0, nc - 1], [3, 3], color=ORANGE, lw=2.6, solid_capstyle='round')
    ax.plot([0, nS - 1], [2, 2], color=BLUE, lw=2.6, solid_capstyle='round')
    ax.plot([0, nL - 1], [1, 1], color=BLUE, lw=2.6, solid_capstyle='round')
    ax.axvspan(t, t + h, color=GRID, alpha=0.7, lw=0)
    ax.plot([t], [3.42], marker='v', color=INK, ms=4.2)
    if tS is not None:
        ax.plot([tS], [2.42], marker='v', color=INK, ms=4.2, mfc='white' if early else INK)
    else:
        ax.text(nS + 1, 1.95, 'not observed through t + h', fontsize=5.6, color=INK2, va='center')
    ax.plot([tL], [1.42], marker='v', color=INK, ms=4.2)
    ax.text(-1.5, 2, lab, ha='right', va='center', fontsize=6.4, color=INK)
    ax.set_yticks([]); ax.set_ylim(0.6, 3.75)
    for sp in ('top', 'right', 'left'): ax.spines[sp].set_visible(False)
for ax in axes[:-1]:
    ax.spines['bottom'].set_visible(False); ax.tick_params(axis='x', length=0)
axes[0].text(nc + 1, 3, 'septic case', fontsize=5.6, color=ORANGE, va='center')
axes[0].text(nL + 1, 1, 'never septic', fontsize=5.6, color=BLUE, va='center')
axes[-1].set_xlabel('Hours since ICU admission'); axes[-1].set_xlim(-1, 78)
fig.subplots_adjust(left=0.27, right=0.98, top=0.98, bottom=0.11, hspace=0.25)
fig.savefig('fig1_rules.png'); plt.close(fig)

# ---------- Fig 2: timing mechanism ----------
td = P[2]['timing_diag']; q = [10, 25, 50, 75, 90, 99]
fig, ax = plt.subplots(figsize=(W, 2.2))
for s, mk in (('A', 'o'), ('B', 's')):
    ax.plot(q, [td[s]['septic_landmark_quantiles'][str(x)] for x in q], color=ORANGE, marker=mk, ms=4, lw=1.5,
            label=f'Septic landmark time, Set {s}', ls='-' if s == 'A' else '--')
    ax.plot(q, [td[s]['nonseptic_length_quantiles'][str(x)] for x in q], color=BLUE, marker=mk, ms=4, lw=1.5,
            label=f'Non-septic stay length, Set {s}', ls='-' if s == 'A' else '--')
ax.axhline(42, color=INK2, lw=0.6, ls=':'); ax.text(11, 45, '42 h', fontsize=6, color=INK2)
ax.set_yscale('log'); ax.set_yticks([10, 20, 50, 100, 200]); ax.set_yticklabels(['10', '20', '50', '100', '200'])
ax.set_xticks(q); ax.set_xlabel('Percentile'); ax.set_ylabel('Hours since ICU admission')
clean(ax); ax.legend(fontsize=6, loc='upper left', ncol=1)
fig.tight_layout(); fig.savefig('fig2_mechanism.png'); plt.close(fig)

# ---------- Fig 3: self-evaluation gap (three model families) ----------
import results_summary_02 as Q7
LAB = ['Discharge-anchored', 'Relative time', 'Absolute, clipped', 'Absolute, existing', 'Absolute, horizon',
       'Feasible onset', 'Risk set', 'Risk set + later cases']
sty = {'AtoB': (ORANGE, 'o', 'A→B'), 'BtoA': (ORANGE, 's', 'B→A'), 'AtoA': (BLUE, 'o', 'Within A'), 'BtoB': (BLUE, 's', 'Within B')}
off = {'AtoB': -0.27, 'BtoA': -0.09, 'AtoA': 0.09, 'BtoB': 0.27}
fig, ax = plt.subplots(figsize=(W, 2.9))
y = np.arange(len(Q7.D))[::-1]
for s, (c, mk, lab) in sty.items():
    g = np.array([[Q7.gap(s, fam, d) for fam in Q7.FAM] for d in Q7.D])
    yy = y + off[s]
    ax.hlines(yy, g.min(1), g.max(1), color=c, lw=0.9)
    ax.plot(g.mean(1), yy, ls='none', marker=mk, color=c, ms=3.4, mfc=c if s in ('AtoB', 'AtoA') else 'white', label=lab)
ax.axvline(0, color=INK2, lw=0.8, ls='--')
ax.set_yticks(y); ax.set_yticklabels(LAB, fontsize=6.3)
ax.set_xlabel('Own-cohort AUROC − replay AUROC')
ax.set_xticks([-0.025, 0, 0.025, 0.05, 0.075, 0.1, 0.125]); ax.set_xticklabels(['−0.025', '0', '0.025', '0.050', '0.075', '0.100', '0.125'], fontsize=6)
clean(ax, 'x'); ax.legend(fontsize=6, ncol=4, loc='upper center', bbox_to_anchor=(0.35, 1.12), handletextpad=0.2, columnspacing=0.8)
fig.tight_layout(); fig.savefig('fig3_gap.png'); plt.close(fig)
print('Figures written to the current folder')
