"""Summaries of results_02.json used by the tables and figures."""
import json, numpy as np
from scipy.stats import spearmanr
J = json.load(open('../results/results_02.json')); A = J['audit']
D = ['discharge', 'relative', 'absolute', 'absolute_exist', 'absolute_horizon', 'feasible', 'riskset', 'riskset_future']
FAM = ['GB', 'LR', 'RF']; SET = ['AtoB', 'BtoA', 'AtoA', 'BtoB']
VAR = ['primary', 'with_initially_positive', 'all_hours', 'lead6']
HOURS = np.arange(5, 43)
def sd(s): return list(A[s]['seeds'].values())
def keys(fams=FAM): return [f'{f}|{d}' for f in fams for d in D]
def mean_over_seeds(s, f): return float(np.mean([f(r) for r in sd(s)]))
def agree(s, d2, var='primary', fams=FAM, metric='AUROC'):
    """bias, MAE, Spearman over models for test rule d2 against replay variant var (seed means)."""
    ks = keys(fams)
    est = np.array([mean_over_seeds(s, lambda r: r['models'][k]['matrix'][d2]) for k in ks])
    if metric == 'eqp':
        rp = np.array([mean_over_seeds(s, lambda r: r['models'][k]['replay']['primary']['AUROC_equal_patient']) for k in ks])
    else:
        rp = np.array([mean_over_seeds(s, lambda r: r['models'][k]['replay'][var]['AUROC']) for k in ks])
    return dict(bias=float(np.mean(est - rp)), mae=float(np.mean(np.abs(est - rp))), rho=float(spearmanr(est, rp)[0]),
                maxabs=float(np.max(np.abs(est - rp))))
def inside(s, d2, tol=0.05, var='primary', first500=False, fams=FAM):
    q = 'q_first500' if first500 else 'q'
    ks = keys(fams); B = A[s]['bootstrap']
    return sum((B[k][d2][var][q][0] > -tol) and (B[k][d2][var][q][1] < tol) for k in ks), len(ks)
def inside_tot(d2, tol=0.05, var='primary', first500=False):
    return sum(inside(s, d2, tol, var, first500)[0] for s in SET)
def gap(s, f, d, var='primary'):
    return mean_over_seeds(s, lambda r: r['models'][f'{f}|{d}']['matrix'][d] - r['models'][f'{f}|{d}']['replay'][var]['AUROC'])
def rep(s, f, d, var='primary', key='AUROC'):
    return mean_over_seeds(s, lambda r: r['models'][f'{f}|{d}']['replay'][var][key])
def own(s, f, d): return mean_over_seeds(s, lambda r: r['models'][f'{f}|{d}']['matrix'][d])
def cm_shift(s, d2):
    return float(np.mean([r['models'][k]['matrix_count_matched'][d2] - r['models'][k]['matrix'][d2] for r in sd(s) for k in keys()]))
def probe(s, d): return mean_over_seeds(s, lambda r: r['probe_linear'][d])
def cohort(s, d, part='test', k='controls'): return mean_over_seeds(s, lambda r: r['cohorts'][d][part][k])
def band_weights(s, d, bands=((5, 12), (13, 24), (25, 36), (37, 42))):
    """control landmarks per replay negative hour in each band, relative to the overall ratio (seed 0)."""
    neg = np.array(A[s]['replay']['primary']['negative_hours_by_hour'], float)
    c = np.array(A[s]['seeds']['0']['cohorts'][d]['test']['control_landmarks_by_hour'], float)
    tot = c.sum() / neg.sum()
    return [float(c[(HOURS >= a) & (HOURS <= b)].sum() / neg[(HOURS >= a) & (HOURS <= b)].sum() / tot) for a, b in bands]
