# Control sampling and reported performance in early sepsis prediction

Code and results for the paper *Control Sampling Determines Reported Performance in Early Sepsis Prediction: A Comparative Audit of Matching Rules against Hourly Replay*.

## Data

All analyses use the training release (version 1.0.0) of the PhysioNet/Computing in Cardiology Challenge 2019 database, which is openly available from PhysioNet under the CC BY 4.0 licence. Each notebook downloads it from the PhysioNet open-data mirror; no credentials are needed.

## Running the analyses

Open a notebook in Google Colab, select a CPU runtime and choose Runtime > Run all. Each notebook writes one JSON file of results; the files used for the paper are in `results/`. Seeds are fixed in the code. In `01_matching_rule_audit.ipynb`, stays are split before matching (seed 2026 for the within-system splits), matching seeds are 0-4 (transfer) and 0-2 (within systems) in notebook 01 and 0-2 and 0-1 in notebook 02; models use random_state 2026; notebook 02 draws 1,000 bootstrap replicates per setting with seeds 7-10.

| Notebook | Results file | Content in the paper |
|---|---|---|
| `01_matching_rule_audit.ipynb` | `results_01.json` | Locked cases (Section III-A), Table II, timing probes and paired bootstrap between test cohorts (Section IV-B, IV-C) |
| `02_replay_agreement.ipynb` | `results_02.json` | Eight rules x three model families, Tables III-V, Fig. 3, replay definitions, count-matched cohorts and seed-averaged bootstrap intervals (Sections IV-C to IV-E and V-B) |
| `03_record_timing_and_landmark_designs.ipynb` | `results_03.json` | Hours recorded after onset (Section IV-A) |
| `04_timing_percentiles_and_full_window_designs.ipynb` | `results_04.json` | Fig. 2 and the percentiles in Section IV-A |
| `05_hourly_evaluation_designs.ipynb` | `results_05.json` | Hourly evaluation designs (Section V-C) |

Notebooks 03-05 also contain exploratory analyses that are not reported in the paper. `results_01.json` and `results_02.json` contain the full train-test matrices and seed-level metrics. `results/agreement_intervals.csv` lists the landmark and replay AUROC and the seed-averaged bootstrap interval of their difference for each of the 8 test rules x 24 models x 4 settings, and `results/check_headline_counts.py` recomputes the interval counts of Table III from it.

`figures/make_figures.py` regenerates Figs. 1-3 from `results/`:

```
cd figures
python make_figures.py
```

## Software

Python 3 with numpy, pandas, scipy, scikit-learn (version 1.6.1 for the reported results) and matplotlib as provided by Google Colab; awscli is installed by the download cell.

## Licence

The code is released under the MIT licence. The PhysioNet/CinC 2019 data remain under their CC BY 4.0 licence.
